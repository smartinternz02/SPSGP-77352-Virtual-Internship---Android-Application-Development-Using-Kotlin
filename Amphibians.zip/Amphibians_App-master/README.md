# Amphibians 
An app that displays information about different amphibian species

## What I applied
- The knowledge of Networking, Json parsing and ViewModels to enable usage of data from the internet
- Retrieving data from a custom API and display it in a list view

## Note
**This is my finished version of the project for Unit 4: Connect to the Internet, Android Basics in Kotlin**
