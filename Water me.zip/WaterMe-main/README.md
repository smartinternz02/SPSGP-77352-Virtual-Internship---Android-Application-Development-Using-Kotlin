Water Me App
==================================

Starter code for the fourth independent project for Android Basics in Kotlin. This project pairs
with Unit 6 of Android Basics in Kotlin

Introduction
------------

This is the starter code for the Water Me app project. This project is an opportunity for you to
demonstrate the concepts you learned in Unit 6 of Android Basics in Kotlin.

Pre-requisites
--------------

- Complete Unit 1 of Android Basics in Kotlin
- Complete Project 1: Lemonade App
- Complete Unit 2 of Android Basics in Kotlin
- Complete Project 2: Dogglers
- Complete Unit 3 of Android Basics in Kotlin
- Complete Project 3: Lunch Tray
- Complete Unit 4 of Android Basics in Kotlin
- Complete Project 4: Amphibians
- Complete Unit 5 of Android Basics in Kotlin
- Complete Project 5: Forage
- Complete Unit 6 of Android Basics in Kotlin
